import os
import sys
import time

print("Create by WGSudio by Wint Khant Lin")
username = input("Your username: ")

print("Welcome back "+ username)
while True:
    com = input(username+"@linux[-]: ")
    os.system(com)